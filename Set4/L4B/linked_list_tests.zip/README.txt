/* CSCI261 Lab
 *
 * Author: YOUR NAME
 *
 * This program executes some tests that illustrate the properties
 * and behaviors of linked lists.
 *
 * Copyright 2022 Dr. Jeffrey Paone
 */

Your task is to implement the functions defined in linked_list_functions.h such that all of the tests within the test suite pass.