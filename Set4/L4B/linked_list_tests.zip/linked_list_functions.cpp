#include "linked_list_functions.h"

Node* linked_list_make_node(const int VALUE) {
    // TODO #1
    return nullptr;
}

int linked_list_get_size(Node* pHead) {
    // TODO #2
    return -999;
}

Node* linked_list_add_value_to_front(Node* pHead, const int VALUE) {
    // TODO #3
    return nullptr;
}

int linked_list_get_value_at_position(Node* pHead, const int POS) {
    // TODO #4
    return -999;
}

int linked_list_min(Node* pHead) {
    // TODO #5
    return -999;
}

int linked_list_max(Node* pHead) {
    // TODO #6
    return -999;
}

int linked_list_find(Node* pHead, const int TARGET) {
    // TODO #7
    return -999;
}

Node* linked_list_remove_node_from_front(Node* pHead) {
    // TODO #8
    return nullptr;
}

Node* linked_list_set_value_at_position(Node* pHead, const int POS, const int VALUE) {
    // TODO #9
    return nullptr;
}